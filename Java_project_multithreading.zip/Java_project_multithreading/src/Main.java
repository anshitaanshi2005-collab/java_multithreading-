import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Shared list to store found characters, initialized with nulls
        ArrayList<Character> thePass = new ArrayList<>();
        
        ValidatePass validatePass = new ValidatePass();
        FindPass findPass = new FindPass(thePass);
        FindPassCapital secondFindPass = new FindPassCapital(thePass);
        
        // Initialize the list with null for each character in the password
        for (int i = 0; i < findPass.password.length; i++) {
            thePass.add(null);
        }
        
        Thread runScan0 = new Thread(findPass);
        Thread runScan1 = new Thread(secondFindPass);
        
        runScan0.start();
        runScan1.start();
        
        try {
            runScan0.join();
            runScan1.join();
        } catch (InterruptedException e) {
            System.out.println(e);
        }
        
        validatePass.found(thePass);
    }
}
