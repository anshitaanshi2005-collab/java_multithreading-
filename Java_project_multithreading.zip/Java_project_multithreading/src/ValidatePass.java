import java.util.ArrayList;

public class ValidatePass {
    public void found(ArrayList<Character> passNow) {
        StringBuilder buildPass = new StringBuilder();
        for (Character ch : passNow) {
            if (ch != null)
                buildPass.append(ch);
            else
                buildPass.append('?');  // or other placeholder for unfound chars
        }
        System.out.println("( Password is : " + buildPass + " )");
    }
}

