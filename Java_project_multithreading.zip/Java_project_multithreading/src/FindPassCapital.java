import java.util.ArrayList;

public class FindPassCapital implements Runnable {
    private ArrayList<Character> valList;
    public char[] password = "userDawin".toCharArray();

    public FindPassCapital(ArrayList<Character> value) {
        this.valList = value;
    }

    @Override
    public void run() {
        // Find uppercase letters
        for (int x = 0; x < password.length; x++) {
            for (char capital = 'A'; capital <= 'Z'; capital++) {
                if (password[x] == capital) {
                    System.out.println("Capital Thread [ID-" + Thread.currentThread().getId() + "] Found ->> " + capital);
                    valList.set(x, capital);
                    break;
                } else {
                    System.out.println("Thread [ID-" + Thread.currentThread().getId() + "] Searching.. " + capital);
                }
            }
        }
    }
}

