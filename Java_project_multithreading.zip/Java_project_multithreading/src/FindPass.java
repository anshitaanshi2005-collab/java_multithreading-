import java.util.ArrayList;

public class FindPass implements Runnable {
    private ArrayList<Character> valList;
    public char[] password = "userDawin".toCharArray();

    public FindPass(ArrayList<Character> value) {
        this.valList = value;
    }

    @Override
    public void run() {
        // Find lowercase letters
        for (int x = 0; x < password.length; x++) {
            for (char nonCapital = 'a'; nonCapital <= 'z'; nonCapital++) {
                if (password[x] == nonCapital) {
                    System.out.println("non-Capital Thread [ID-" + Thread.currentThread().getId() + "] Found ->> " + nonCapital);
                    valList.set(x, nonCapital);
                    break;
                } else {
                    System.out.println("Thread [ID-" + Thread.currentThread().getId() + "] Searching.. " + nonCapital);
                }
            }
        }
    }
}

