# Multithreading-Runnable-Java
This case use multithreading implements Runnable from Java and split 2 task to get the objective in multithread usage.

### Objective:
- String password on this code must can scan every alphabet in this string.
- Scan alphabet from A-Z with multithreading have each task as well (Capital / nonCapital) 
- Statement about this case must be right to show the output in the String Password.
